/*
 * Client.h
 *
 *  Created on: May 24, 2013
 *      Author: posilva
 */

#ifndef CLIENT_H_
#define CLIENT_H_
namespace arte{
namespace core{
class Client {
public:
	Client();
	virtual ~Client();
};

}
}

#endif /* CLIENT_H_ */

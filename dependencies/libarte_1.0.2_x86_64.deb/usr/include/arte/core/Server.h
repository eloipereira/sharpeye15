/*
 * Server.h
 *
 *  Created on: May 24, 2013
 *      Author: posilva
 */

#ifndef SERVER_H_
#define SERVER_H_
#include <vector>
#include <arte/io/IOMultiplexer.h>
#include <arte/net/TCPSocket.h>
#include <arte/core/Client.h>
namespace arte {
namespace core {
class Server {
 public:
  Server();
  virtual ~Server();
  bool start(int port);

  const std::vector<Client>& getClients() const {
    return clients_;
  }
 private:
  arte::io::IOMultiplexer iomux_;
  std::vector<Client> clients_;
  arte::net::TCPSocket server_socket_;
};
}
}
#endif /* SERVER_H_ */

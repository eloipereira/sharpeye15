// ==========================================================================
// Copyright (C) 2013 Força Aérea Portuguesa - Academia                     =
// Centro de Investigação da Academiafa da Força Aérea                      =
// Granja do Marques, Academia, Pero-Pinheiro                               =
// ==========================================================================
// Date:                                                                    =
// Author: Pedro Marques da Silva                                           =
// -------------------------------------------------------------------------=
// Change Log:                                                              =
// -------------------------------------------------------------------------=
// Date       / Author              /Description                            =
// ==========================================================================
// Description:
// ==========================================================================
#ifndef TCPSERVER_H_
#define TCPSERVER_H_

#include <stdio.h>
#include <netinet/in.h>
#include <string>

#include <arte/io/IOMultiplexer.h>
#include <arte/net/Commons.h>
namespace arte {
namespace net {
class TCPSocket {
public:
	TCPSocket(bool block=false);
	virtual
	~TCPSocket();
	bool
	server(const int& port);
	bool
	connect(const std::string& host, const int& port);
	TCPSocket*
	accept();
	int
	readSocket(int socket, unsigned char* buffer, size_t size);
	int
	writeSocket(int socket, const unsigned char* buffer, size_t size);

	int
	read(unsigned char* buffer, size_t size);
	int
	write(const unsigned char* buffer, size_t size);

	void
	shutdown() throw ();

	bool isBlocking() const {
		return blocking_;
	}

	void setBlocking(bool blockingRead) {
		blocking_ = blockingRead;
	}

	int getIsServer() const {
		return is_server_;
	}

	int getPort() const {
		return port_;
	}

	void setPort(int port) {
		port_ = port;
	}

	bool isReuseaddress() const {
		return reuseaddress_;
	}

	void setReuseaddress(bool reuseaddress) {
		reuseaddress_ = reuseaddress;
	}

	const Address_t&
	getServerAddress() const {
		return serverAddress_;
	}

	void setServerAddress(const Address_t& serverAddress) {
		serverAddress_ = serverAddress;
	}

	void
	registerMultiplexer(arte::io::IOMultiplexer * iomux);
	void
	unregisterMultiplexer(arte::io::IOMultiplexer * iomux);
	bool
	poll(arte::io::IOMultiplexer * iomux, int timeout);
	bool
	isReady(arte::io::IOMultiplexer * iomux);
	bool
	  isReadyW(arte::io::IOMultiplexer * iomux);
	bool
	  isReadyE(arte::io::IOMultiplexer * iomux);

	int getSocket() const {
		return socket;
	}


protected:
	bool
	createSocket();
	bool
	bind();
	bool
	bind(const std::string& host);
	void
	listenSocket();

private:
	void handleSIGPIPE();
	void
	setupNonBlocking();

	void
	setupReuseAddress();

	int port_;
	int socket;
	Address_t serverAddress_;
	static const int c_back_log = 5;
	int is_server_;
	bool blocking_;
	bool reuseaddress_;
};

} /* namespace net */
} /* namespace arte*/
#endif /* TCPSERVER_H_ */

// ==========================================================================
// Copyright (C) 2013 Força Aérea Portuguesa - Academia                     =
// Centro de Investigação da Academiafa da Força Aérea                      =
// Granja do Marques, Academia, Pero-Pinheiro                               =
// ==========================================================================
// Project: ARTE-Debug@build
// Date:    Mar 14, 2013
// Author:  posilva
// -------------------------------------------------------------------------=
// Change Log:
// -------------------------------------------------------------------------=
// Date       / Author              /Description
// ==========================================================================
// Description: ScopedLock.h
//
// ==========================================================================

#ifndef SCOPEDLOCK_H_
#define SCOPEDLOCK_H_
namespace arte {
  namespace thread {
    class ScopedLock {
     public:
      ScopedLock(pthread_mutex_t* m);
      virtual ~ScopedLock();
     private:
      pthread_mutex_t* mutex;

    };
    inline ScopedLock::ScopedLock(pthread_mutex_t* m)
        : mutex(m) {
      pthread_mutex_lock(this->mutex);
    }

    inline ScopedLock::~ScopedLock() {
      pthread_mutex_unlock(this->mutex);
    }

  }
}
#endif /* SCOPEDLOCK_H_ */


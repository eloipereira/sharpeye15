// ==========================================================================
// Copyright (C) 2013 Força Aérea Portuguesa - Academia                     =
// Centro de Investigação da Academiafa da Força Aérea                      =
// Granja do Marques, Academia, Pero-Pinheiro                               =
// ==========================================================================
// Project: ARTE-Debug@build
// Date:    Mar 14, 2013
// Author:  posilva
// -------------------------------------------------------------------------=
// Change Log:
// -------------------------------------------------------------------------=
// Date       / Author              /Description
// ==========================================================================
// Description: TSQueue.h
//  A thread safe queue
// ==========================================================================
#ifndef TSQUEUE_H_
#define TSQUEUE_H_
#include <queue>
#include <pthread.h>
#include <arte/thread/ScopedLock.h>
#include <stdexcept>
namespace arte {
  namespace thread {
template<typename T>
class TSQueue {
public:
	TSQueue();
	virtual ~TSQueue();
	void push(T element);
	bool isEmpty();
	T pop();
	T peek();

private:
	std::queue<T> queue;
	pthread_mutex_t lock;
};

template<typename T>
inline TSQueue<T>::TSQueue() {
	if (pthread_mutex_init(&lock, NULL) != 0) {
		throw std::runtime_error("mutex init failed");
	}
}

template<typename T>
inline TSQueue<T>::~TSQueue() {
	pthread_mutex_destroy(&lock);
}

template<typename T>
inline void TSQueue<T>::push(T element) {
	ScopedLock(&this->lock);

	this->queue.push(element);
}

template<typename T>
inline T TSQueue<T>::pop() {
	ScopedLock(&this->lock);
	T front = this->queue.front();
	this->queue.pop();
	return front;
}


template<typename T>
inline T TSQueue<T>::peek() {
  ScopedLock(&this->lock);
  return this->queue.front();
}
template<typename T>
inline bool TSQueue<T>::isEmpty() {
    return this->queue.empty();
}
  }}
#endif /* TSQUEUE_H_ */


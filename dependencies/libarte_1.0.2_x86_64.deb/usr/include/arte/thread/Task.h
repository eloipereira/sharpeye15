// ==========================================================================
// Copyright (C) 2013 Força Aérea Portuguesa - Academia                     =
// Centro de Investigação da Academiafa da Força Aérea                      =
// Granja do Marques, Academia, Pero-Pinheiro                               =
// ==========================================================================
// Project: ARTE-Debug@build
// Date:    Mar 14, 2013
// Author:  posilva
// -------------------------------------------------------------------------=
// Change Log:
// -------------------------------------------------------------------------=
// Date       / Author              /Description
// ==========================================================================
// Description: Task.h
//
// ==========================================================================

#ifndef TASK_H_
#define TASK_H_
#include <pthread.h>
#include <stddef.h>
namespace arte {
  namespace thread {

    class Task {
     public:
      Task()
          : thread_(0),
            running(false) {

        pthread_attr_init(&thread_settings);
      }
      virtual ~Task() {

      }
      void on_run() {

        this->running = true;
        this->run();
        this->running = false;
      }
      /** Returns true if the thread was successfully started, false if there was an error starting the thread */
      bool start() {
        return (pthread_create(&thread_, 0, ThreadEntryFunc, this) == 0);

      }

      /** Will not return until the internal thread has exited. */
      void wait() {
        (void) pthread_join(thread_, NULL);
      }
      void stop() {
        this->running = false;
        pthread_exit(NULL);
      }
      void destroy() {
        pthread_attr_destroy(&thread_settings);
      }
     protected:
      /** Implement this method in your subclass with the code you want your thread to run. */
      virtual void run() = 0;
      bool running;
     private:
      static void * ThreadEntryFunc(void * This) {
        ((Task *) This)->on_run();
        return 0;
      }
      //!
      pthread_t thread_;
      //!
      pthread_attr_t thread_settings;

    };
  }
}

#endif /* TASK_H_ */

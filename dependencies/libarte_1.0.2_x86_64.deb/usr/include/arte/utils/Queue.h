/*
 * Queue.h
 *
 *  Created on: Feb 18, 2013
 *      Author: posilva
 */

#ifndef QUEUE_H_
#define QUEUE_H_

namespace arte {
namespace utils {

class Queue {
public:
	Queue();
	virtual
	~Queue();
};

} /* namespace Utils */
} /* namespace Core */
#endif /* QUEUE_H_ */

/*
 * MissionSettingsPacket.h
 *
 *  Created on: Jun 25, 2014
 *      Author: posilva
 */

#ifndef MISSIONSETTINGSPACKET_H_
#define MISSIONSETTINGSPACKET_H_
#include <stdint.h>
#include <Piccolo/SDK/SDK.h>
#include <Piccolo/SDK/Utils.h>

namespace Piccolo {
  namespace SDK {
    namespace Core {
      namespace Packets {

        class MissionSettingsPacket {
         private:
          int16_t altitudeMin;
          int16_t altitudeMax;
          uint32_t fligthTimeout;
          static const int MISSION_SETTINGS_PACKET_SIZE = 8;
          uint16_t sourceId;

         public:
          MissionSettingsPacket();
          virtual ~MissionSettingsPacket();
          void load(BYTE_VECTOR* payload);
          uint16_t toRaw(BYTE_VECTOR * payload);

          int16_t getAltitudeMax() const {
            return altitudeMax;
          }

          void setAltitudeMax(int16_t altitudeMax) {
            this->altitudeMax = altitudeMax;
          }

          int16_t getAltitudeMin() const {
            return altitudeMin;
          }

          void setAltitudeMin(int16_t altitudeMin) {
            this->altitudeMin = altitudeMin;
          }

          uint32_t getFligthTimeout() const {
            return fligthTimeout;
          }

          void setFligthTimeout(uint32_t fligthTimeout) {
            this->fligthTimeout = fligthTimeout;
          }
          uint16_t getSourceId() const {
            return sourceId;
          }

          void setSourceId(uint16_t sourceId) {
            this->sourceId = sourceId;
          }
        };

      } /* namespace Packets */
    } /* namespace Core */
  } /* namespace SDK */
} /* namespace Piccolo */

#endif /* MISSIONSETTINGSPACKET_H_ */

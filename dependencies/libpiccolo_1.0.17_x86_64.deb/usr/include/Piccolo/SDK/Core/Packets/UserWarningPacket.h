/*
 * UserWarningPacket.h
 *
 *  Created on: Jun 25, 2014
 *      Author: posilva
 */

#ifndef USERWARNINGPACKET_H_
#define USERWARNINGPACKET_H_
#include <stdint.h>
#include <Piccolo/SDK/SDK.h>

namespace Piccolo {
  namespace SDK {
    namespace Core {
      namespace Packets {

        class UserWarningPacket {
         private:
          uint16_t sourceId;
          uint8_t type;
          uint8_t code;
          std::string warning;
         public:
          UserWarningPacket();
          virtual ~UserWarningPacket();
          void load(BYTE_VECTOR* payload);

          uint8_t getCode() const {
            return code;
          }

          uint8_t getType() const {
            return type;
          }

          const std::string& getWarning() const {
            return warning;
          }

          uint16_t getSourceId() const {
            return sourceId;
          }

          void setSourceId(uint16_t sourceId) {
            this->sourceId = sourceId;
          }
        };

      } /* namespace Packets */
    } /* namespace Core */
  } /* namespace SDK */
} /* namespace Piccolo */

#endif /* USERWARNINGPACKET_H_ */

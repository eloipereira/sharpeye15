/*
 * PiccoloParser.h
 *
 *  Created on: Mar 21, 2014
 *      Author: posilva
 */

#ifndef PICCOLOPARSER_H_
#define PICCOLOPARSER_H_
#include <stdint.h>
#include <Piccolo/SDK/SDK.h>
#include <Piccolo/SDK/Core/Packets/PacketConstants.h>
#include <Piccolo/SDK/Utils.h>

namespace Piccolo {
  namespace SDK {
    namespace Core {
      class PiccoloParser {
        enum ParserState {
          SYNC0,
          SYNC1,
          HEADER_DATA,
          CHECK,
          DATA,
          CRC,
          PARSED
        };
        typedef struct {
          ParserState state;
          BYTE_VECTOR buffer;
          uint8_t header_check;
          uint8_t data_size;
          uint16_t crc;
        } ParserStatus;
        static const int C_HEADER_SIZE = 14;
        static const int C_HEADER_CHECK_OFFSET = 13;
        static const int C_DATA_SIZE_OFFSET = 12;
        static const int C_CRC_SIZE= 2;
       public:
        PiccoloParser();
        virtual ~PiccoloParser();
        bool parseStreamPacket(const uint8_t& ch);
        void reset();
        const BYTE_VECTOR& getBuffer();
       protected:
        ParserStatus status;

      };

    } /* namespace Core */
  } /* namespace SDK */
} /* namespace Piccolo */

#endif /* PICCOLOPARSER_H_ */

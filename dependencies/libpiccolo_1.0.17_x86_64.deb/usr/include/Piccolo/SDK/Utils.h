/*
 * Utils.h
 *
 *  Created on: Nov 20, 2012
 *      Author: posilva
 */

#ifndef UTILS_H_
#define UTILS_H_
#include <vector>
#include <iostream>
#include <sstream>
#include <string>
#include <cmath>
#include <cstring>
#include <stdint.h>

#include <boost/crc.hpp>

#include <Piccolo/SDK/SDK.h>

#include <bitset>
#include <math.h>

#define GET_BITS(v,b,e)  ((v & (((1 << ((e - b) + 1)) - 1) << b)) >> b)
#define GET_BIT(v,b)  ((v & (((1 << 1) - 1) << b)) >> b)
#define SET_BIT(v,b) (v |= 1 << b)
#define UNSET_BIT(v,b) (v &= ~(1 <<  b))

namespace Piccolo {
  namespace SDK {
    class Utils {
     public:
      union u_u32_s23e8 {
	unsigned int i;
	float f;
      };

      Utils();
      virtual
      ~Utils();
      static inline float groundSpeed(const float& vx, const float& vy,
                                      const float& vz) {
        return sqrt(vx * vx + vy * vy + vz * vz);
      }
      static inline bool isValidWaypoints(const uint8_t& value) {
        return value == 0;
      }
      static inline bool isDeleteWaypoints(const uint8_t& value) {
        return value == 1;
      }
      static inline bool isAllWaypoints(const uint8_t& value) {
        return value == 2;
      }
      static inline bool isWaypointsTransfer(const uint8_t& value) {
        return value == 2;
      }

      static inline bool

      isLeftTurn(const bool& value) {
        return value == 0;
      }
      static inline bool isRigthTurn(const bool& value) {
        return value == 1;
      }
      static inline float fromOrbitMult10(const int& value) {
        return value * 10;
      }
      static inline float fromOrbitMult50(const int& value) {
        return value * 50;
      }
      static inline float from8OfMToM(const int& value) {
        return value * .125;
      }

      static inline float fromTenOfSecToSec(const int& value) {
        return value / 10;
      }
      static inline float fromCmAGL(const int& value) {
        return normalize0To2PI(value / 100);
      }
      static inline float fromIAS(const int& value) {
        return fromCmPerSecToMPerSecTo((-2000 + value));
      }
      static inline int toIAS(const float& value) {
        return (2000 + value) * 100.0;
      }
      static inline float from10KUnit(const int& value) {
        return (value / 10000.0);
      }

      static inline float from10KRadToDeg(const int& value) {
        return from10KUnit(value) * 180 / M_PI;
      }
      static inline float fromRadToDeg(const float& value) {
        return value * 180 / M_PI;
      }

      static inline float normalize0To2PI(const float& value) {
        return value < 0 ? 360 + value : value;
      }
      static inline bool isON(const uint8_t& value) {
        return value == 1;
      }
      static inline bool isOFF(const uint8_t& value) {
        return value == 0;
      }
      static inline bool isAUTO(const uint8_t& value) {
        return value == 2;
      }
      static inline float fromCmPerSecToMPerSecTo(const int& value) {
        return value / 100.0;
      }
      static inline float fromMPerSecToCmPerSecTo(const float& value) {
        return value * 100.0;
      }

      static inline float fromAltitudeCMBelowWGS84(const int& value) {
        return value / 100.0 - 1000;
      }
      static inline int toAltitudeCMBelowWGS84(const float& value) {
        return value * 100 + 1000;
      }
      static inline float fromMilliArcSeconds(const int& value) {
        return value / 3600000.0;
      }
      static inline int toMilliArcSeconds(const float& value) {
        return value * 3600000;
      }

      static inline float fromHeight16(const int& value) {
        return (value / 2.0) - 1000;
      }
      static inline int toHeight16(const float& value) {
        return (value + 1000) * 2.0;  //Height16 = (Height + 1000)*2.0
      }

      static inline float fromGPS24(const int& value) {
        return (value / GPS24_INT_LIMIT_2PI ) - M_PI;
      }
      static inline int toGPS24(const float& value) {
        return (value + M_PI) * GPS24_INT_LIMIT_2PI ;  //Lat24=(Longitude + PI) * (16777216/2PI)
      }
      static inline float fromLat24(const int& value) {
        return fromGPS24(value);
      }

      static inline int toLat24(const float& value) {
        return toGPS24(value);
      }
      static inline float fromLon24(const int& value) {
        return fromGPS24(value);
      }

      static inline int toLon24(const float& value) {
        return toGPS24(value);
      }

      static inline int strToInt(const std::string& s) {
        return strToInt(s.c_str());
      }
      static inline int strToInt(const char* s) {
        std::istringstream buffer(s);
        int value;
        buffer >> value;
        return value;
      }
      static inline bool isBigEndian() {
        int i = 1;
        char *p = (char *) &i;

        if (p[0] == 1)
          return false;
        else
          return true;
      }
      static inline float DegreestoRad(const float& degrees) {
        return degrees * M_PI / 180;
      }
      static inline uint16_t Int32toUCharA(const int& i, BYTE* buffer) {
        buffer[0] = (BYTE) (i >> 24);
        buffer[1] = (BYTE) (i >> 16);
        buffer[2] = (BYTE) (i >> 8);
        buffer[3] = (BYTE) (i /*>> 0*/);

        return 4;
      }

      static inline BYTE*
      Int32toUCharA(const int& i) {
        BYTE *result = new BYTE[4];
        result[0] = (BYTE) (i >> 24);
        result[1] = (BYTE) (i >> 16);
        result[2] = (BYTE) (i >> 8);
        result[3] = (BYTE) (i /*>> 0*/);

        return result;
      }

      static inline BYTE*
      FloattoUCharA(const float& i) {
        BYTE *buffer = new BYTE[4];

        size_t sz = sizeof(i);
        std::memcpy(buffer, &i, sz);

        if (!isBigEndian()) {
          BYTE *swap = new BYTE[4];
          for (unsigned int i = 0; i < sz; i++) {
            swap[i] = buffer[sz - 1 - i];
          }
          delete buffer;
          return swap;
        }

        return buffer;
      }
      static inline uint16_t ShorttoUCharA(const short& i, BYTE *buffer) {
        buffer[0] = (BYTE) (i >> 8);
        buffer[1] = (BYTE) (i /*>> 0*/);
        return 2;
      }
      static inline BYTE*
      ShorttoUCharA(const short& i) {
        BYTE *result = new BYTE[2];
        result[0] = (BYTE) (i >> 8);
        result[1] = (BYTE) (i /*>> 0*/);
        return result;
      }

      static inline unsigned short UChar2UShort(const BYTE *value) {
        return (unsigned short) (((value[0] & 0xff) << 8) | (value[1] & 0xff));
      }

      static inline unsigned short UChar2UShort(const BYTE& left,
                                                const BYTE& rigth) {
        return (unsigned short) (((left & 0xff) << 8) | (rigth & 0xff));
      }

      static inline short UChar2Short(const BYTE& left, const BYTE& rigth) {
        return (short) (((left & 0xff) << 8) | (rigth & 0xff));
      }

      static inline unsigned int UChar2UInt32(const BYTE *value) {
        return (unsigned int) (((value[0] & 0xff) << 24)
            | ((value[1] & 0xff) << 16) | ((value[2] & 0xff) << 8)
            | (value[3] & 0xff));

      }
      static inline unsigned int UChar2UInt24(const BYTE *value) {
        return (unsigned int) (((value[0] & 0xff) << 16)
            | ((value[1] & 0xff) << 8) | (value[2] & 0xff));

      }
      static inline int UChar2Int32(const BYTE *value) {
        return (int) (((value[0] & 0xff) << 24) | ((value[1] & 0xff) << 16)
            | ((value[2] & 0xff) << 8) | (value[3] & 0xff));
      }
      static inline short UChar2Int16(const BYTE *value) {
        return (short) (((value[0] & 0xff) << 8) | (value[1] & 0xff));
      }
      static inline unsigned int UChar2Int24(BYTE *value) {
        return (unsigned int) (((value[0] & 0xff) << 16)
            | ((value[1] & 0xff) << 8) | (value[2] & 0xff));
      }
      static inline unsigned short CRC16(const BYTE_VECTOR& packet,
                                         const int& size) {
        return CRC16(&packet[0], size);
      }
      static inline unsigned short CRC16(const BYTE* a, const int& size) {
        boost::crc_16_type crc;
        crc.process_bytes(a, size);
        unsigned short crc_calculated = crc.checksum();
        return crc_calculated;
      }
      static inline BYTE CheckXOR(const BYTE_VECTOR& packet,
                                  const size_t& size) {
        BYTE value = packet[0];
        for (size_t i = 1; i < size; ++i) {

          value = value ^ packet[i];
        }
        return (BYTE) (unsigned short) value;
      }
      static inline BYTE CheckXOR(const BYTE * packet, const size_t& size) {
        BYTE value = packet[0];
        for (size_t i = 1; i < size; ++i) {
          value = value ^ packet[i];
        }
        return (BYTE) (unsigned short) value;
      }
      static inline std::ostream&
      out() {
        return std::cout << std::dec;
      }

      static inline unsigned createMask(const unsigned& start,
                                        const unsigned& end) {
        unsigned r = 0;
        for (unsigned i = start; i <= end; i++)
          r |= 1 << i;
        return r;
      }
      template<typename T>
      static inline T getBits(const T& value, const uint8_t& begin,
                              const uint8_t& end) {
        return GET_BITS(value, begin, end);
      }

      template<typename T>
      static inline T getBitsR(const T& value, const uint8_t& begin,
                               const uint8_t& end) {
        uint8_t size = (sizeof(T) * 8);
        return GET_BITS(value, (size - 1 - end), (size - 1 - begin));
      }
      template<typename T>
      static inline bool getBit(const T&value, const uint8_t& bit) {
        return GET_BIT(value, bit);
      }
      template<typename T>
      static inline bool setBit(T value, const uint8_t& bit, bool set = true) {
        if (set)
          return SET_BIT(value, bit);
        else
          return UNSET_BIT(value, bit);
      }
      template<typename T>
      static inline bool getBitR(const T& value, const uint8_t& bit) {
        uint8_t size = (sizeof(T) * 8);
        return GET_BIT(value, (size - 1 - bit));
      }
      template<typename T>
      static inline bool setBitR(T value, const uint8_t& bit, bool set = true) {
        uint8_t size = (sizeof(T) * 8);
        if (set)
          return SET_BIT(value, size - 1 - bit);
        else
          return UNSET_BIT(value, size - 1 - bit);
      }

      static inline float halfToFloat(const uint16_t h) {
        
	uint16_t hs, he, hm;
	uint32_t xs, xe, xm;
	int32_t xes;
	int e;
	uint32_t xp;
    
	if( (h & 0x7FFFu) == 0 ) {  // Signed zero
	  xp = ((uint32_t) h) << 16;  // Return the signed zero
	} else { // Not zero
	  hs = h & 0x8000u;  // Pick off sign bit
	  he = h & 0x7E00u;  // Pick off exponent bits
	  hm = h & 0x01FFu;  // Pick off mantissa bits
	  if( he == 0 ) {  // Denormal will convert to normalized
	    e = -1; // The following loop figures out how much extra to adjust the exponent
	    do {
	      e++;
	      hm <<= 1;
	    } while( (hm & 0x0200u) == 0 ); // Shift until leading bit overflows into exponent bit
	    xs = ((uint32_t) hs) << 16; // Sign bit
	    xes = ((int32_t) (he >> 9)) - 31 + 127 - e; // Exponent unbias the halfp, then bias the single
	    xe = (uint32_t) (xes << 23); // Exponent
	    xm = ((uint32_t) (hm & 0x01FFu)) << 14; // Mantissa
	    xp = (xs | xe | xm); // Combine sign bit, exponent bits, and mantissa bits
	  } else if( he == 0x7E00u ) {  // Inf or NaN (all the exponent bits are set)
	    if( hm == 0 ) { // If mantissa is zero ...
	      xp = (((uint32_t) hs) << 16) | ((uint32_t) 0x7F800000u); // Signed Inf
	    } else {
	      xp = (uint32_t) 0xFFC00000u; // NaN, only 1st mantissa bit set
	    }
	  } else { // Normalized number
	    xs = ((uint32_t) hs) << 16; // Sign bit
	    xes = ((int32_t) (he >> 9)) - 31 + 127; // Exponent unbias the halfp, then bias the single
	    xe = (uint32_t) (xes << 23); // Exponent
	    xm = ((uint32_t) hm) << 14; // Mantissa
	    xp = (xs | xe | xm); // Combine sign bit, exponent bits, and mantissa bits
	    
	  }
	}
	
	float out;
	out = *((float*) &xp);
	return out;
      };

     static inline float halfToFloatAlt(const uint16_t h) {
	register int s = h & 0x8000;
	register int e = (h & 0x7e00) >> 9;
	register int m = h & 0x01ff;
	u_u32_s23e8 x;

	s <<= 16;
	if (e == 63) {
	  // infinity or NAN
	  e = 255 << 23;
	  m <<= 14;
	  x.i = s | e | m;
	} else if (e > 0) {
	  // normalized
	  e = e + (127 - 31);
	  e <<= 23;
	  m <<= 14;
	  x.i = s | e | m;
	} else if (m == 0) {
	  // zero
	  x.i = s;
	} else {
	  // subnormal, value is m times 2^-24
	  x.f = ((float) m);
	  x.i = s | (x.i - (24 << 23));
	}
	return(x.f);
      };

     static inline float halfToFloatAlt(const BYTE left,const BYTE right) {
       // std::cout << "\n Input bytes: Left " << std::bitset<8>(left) << " Right: " << std::bitset<8>(right) << std::endl;
      return halfToFloatAlt(UChar2UShort(left,right));
    }

     static inline float int32ToFloat(const int32_t val){
       return *(float *)&val;
     }

     private:
      static const int GPS24_INT_LIMIT_2PI = 16777216 / (2*M_PI);
    };

    

  } /* namespace SDK */
} /* namespace Piccolo */
#endif /* UTILS_H_ */

/*
 * CommunicationManager.h
 *
 *  Created on: Dec 6, 2012
 *      Author: posilva
 */

#ifndef COMMUNICATIONMANAGER_H_
#define COMMUNICATIONMANAGER_H_

#include <Piccolo/SDK/Core/Connection.h>
#include <Piccolo/SDK/Core/Packets/AutopilotStream.h>
#include <Piccolo/SDK/Core/Packets/PacketConstants.h>
#include <Piccolo/SDK/Core/Packets/Packets.h>
#include <Piccolo/SDK/Core/Packets/PayloadStream.h>
#include <Piccolo/SDK/Core/PiccoloParser.h>
#include <Piccolo/SDK/SDK.h>
#include <stddef.h>
#include <stdint.h>
#include <vector>

namespace Piccolo {
  namespace SDK {
    namespace Core {
      static const int COMMS_BUFFER_MAX = 4096; //4096
      static const int APSTREAM_FOOTER_SIZE = 2;
      static const int APSTREAM_HEADER_SIZE = 4;
      static const int STREAM_PACKET_FOOTER_SIZE = 2;
      static const int STREAM_PACKET_HEADER_SIZE = 14;
      enum ConnectionType {
        SERIAL = 0,
        SOCKET = 1
      };
      /**
       * Enum to support states
       */
      enum AutopilotStreamParserState {
        SYNC1,  //!< SYNC1 Parsing 0xa0
        SYNC2,  //!< SYNC2 Parsing 0x05
        TYPE,  //!< TYPE  Parsing type of autopilot stream packet
        SIZE,  //!< SIZE  Size of the packet
        DATA,  //!< DATA  Data containing the fields of packet
        CRC   //!< CRC   Packet Checksum State
      };
      /**
       * Data structure to handle autopilot stream messages parsing
       */
      typedef struct {
        uint8_t state;
        int16_t index;
        uint8_t type;
        uint8_t size;
        uint16_t crc;

        BYTE_VECTOR buffer;
      } APStreamParserStatus;
      /**
       * Struct to read data
       */
      typedef struct {
        unsigned char buffer[COMMS_BUFFER_MAX];      //< buffer to keep data
        size_t last_index;                            //< current index
        size_t len;                                   //< len of the buffer
      } CommQueue;


      /**
       * Data structure to get generic data from every piccolo packet
       */
      typedef struct {
        uint8_t stream;
        int16_t type;
        uint8_t size;
        BYTE_VECTOR data;
      } GenericPiccoloPacketInfo;

      class CommunicationManager {
       public:
        CommunicationManager(ConnectionType connType, PARAMETERS_T params);
        virtual
        ~CommunicationManager();
        void
        init();
        //!
        bool
        getStream(const Piccolo::SDK::Core::Packets::StreamType& stream,
                  BYTE_VECTOR& payload);
        bool
        getStreams(
            std::vector<Piccolo::SDK::Core::Packets::StreamType>& streams,
            BYTE_VECTOR& payload);

        /**
         * Send methods
         *
         */
        //!
        bool
        SendPayloadPacket(BYTE_VECTOR *data);

        bool SendPayloadPacket(unsigned short source,
                               unsigned short destination, BYTE_VECTOR *data);
        bool
               SendGimbalPacket(BYTE_VECTOR *data);

               bool SendGimbalPacket(unsigned short source,
                                      unsigned short destination, BYTE_VECTOR *data);
        //!
        bool SendAutopilotCommandPacket(unsigned short source,
                                        unsigned short destination, BYTE loop,
                                        float value, BYTE control,
                                        bool persistEE);
        bool
        SendAutopilotCommandPacket(BYTE loop, float value, BYTE control = 1,
                                   bool persistEE = false);

        //!
        bool
        SendTrackPacket(BYTE to, BYTE go_to);

        bool
        SendTrackPacket(unsigned short source, unsigned short destination,
                        BYTE to, BYTE go_to);
        //!
        bool
        SendWaypointListPacket(
            Piccolo::SDK::Core::Packets::WaypointListPacket& pkt);
        bool
        SendWaypointListPacket(
            unsigned short source, unsigned short destination,
            Piccolo::SDK::Core::Packets::WaypointListPacket& pkt);
        //!
        bool
        SendWaypointPacket(Piccolo::SDK::Core::Packets::WaypointPacket &pkt);
        bool
        SendWaypointPacket(unsigned short source, unsigned short destination,
                           Piccolo::SDK::Core::Packets::WaypointPacket &pkt);
        //!
        bool
        SendData(BYTE * data, size_t size);
        //!
        bool
        SendAutopilotStreamPacket(uint8_t type, BYTE_VECTOR* datac);
        //!
        bool
        SendAutopilotStreamPacket(unsigned short source,
                                  unsigned short destination, uint8_t type,
                                  BYTE_VECTOR* datac);
        bool
        SendAutopilotStreamPacket(uint8_t type);
        //!
        bool
        SendAutopilotStreamPacket(unsigned short source,
                                  unsigned short destination, uint8_t type);


        //!
        void GetDataFromStreamPacket(const BYTE_VECTOR & packet,
                                     BYTE_VECTOR * data);

        /**
         * Getters and Setters
         */
        unsigned short getAddress() const {
          return address;
        }
        //!
        void setAddress(unsigned short address) {
          this->address = address;
        }
        //!
        unsigned short getRemoteAddress() const {
          return remoteAddress;
        }
        //!
        void setRemoteAddress(unsigned short remoteAddress) {
          this->remoteAddress = remoteAddress;
        }
        //! consume autopilot stream messages from a stream packet
        //! handles packet fragmentation
        bool
        consumeAPStreamPacket(const BYTE_VECTOR & sPacket,
                                   BYTE_VECTOR * apPacket);

       protected:

        //! Parse a received packet
        bool
        parse(BYTE_VECTOR& packet);
        //! Creation of a generic stream packet with source and destination assigned
        BYTE_VECTOR *
        createStreamPacket(unsigned short source, unsigned short destination,
                           BYTE streamType, BYTE_VECTOR *data);

        //! Creation of a generic stream packet with default source and destination assigned
        BYTE_VECTOR *
        createStreamPacket(BYTE type, BYTE_VECTOR *data);
        //! Creation of a autopilot packet payload
        BYTE_VECTOR *
        createAutopilotPacket(BYTE type, BYTE_VECTOR *data);
        //! handle autopilot autopilot stream packets
        void
        handleAutopilotStream(BYTE_VECTOR *payload);

       private:
        /**
         *  Member variables
         */
        PiccoloParser parser;
        //!
        CommQueue communicationQueue;

        //! Type of the connection allowed by autopilot
        ConnectionType connectionType;
        //! Connection parameters
        PARAMETERS_T parameters;
        //! Generic connection handler
        Piccolo::SDK::Core::Connection *connection;
        //! Address of this recipient
        unsigned short address;
        //! Address of the last received message
        unsigned short remoteAddress;
        //! Structure to allow the registration of callbacks
        FUNCTIONS_MAP_T packetHandlers;
        //! Set of types of streams to filter
        bool selectedStreams[Piccolo::SDK::Core::Packets::NUM_STREAMS];
        //! Flag to control the communication manager initialization
        bool initialized_;
        //! Attribute to memorize autopilot stream packet state
        APStreamParserStatus apsStatus;
        /**
         * Helper functions
         */
        //! clear the set of selected streams
        void
        resetSelectedStreams();
        //! Called to select a streamn
        void
        selectStreams(
            std::vector<Piccolo::SDK::Core::Packets::StreamType>& streams);
        //! Reset the autopilot stream packet parser status
        void
        resetAPStreamParserStatus(APStreamParserStatus & status);
        //! Reset comms queue structure
        void resetCommsQueue();
      };
    }
  }
}
#endif /* COMMUNICATIONMANAGER_H_ */

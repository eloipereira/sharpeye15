/*
 * NetworkConnection.h
 *
 *  Created on: Nov 19, 2012
 *      Author: posilva
 */

#ifndef NETWORKCONNECTION_H_
#define NETWORKCONNECTION_H_
#include <string>
#include <arte/net/TCPSocket.h>
#include <Piccolo/SDK/Core/Connection.h>

namespace Piccolo {
    namespace SDK {
        namespace Core {
            class NetworkConnection: public Piccolo::SDK::Core::Connection {
                public:
                    NetworkConnection(std::string host, int port,bool non_blocking=false);
                    virtual ~NetworkConnection();
                    virtual bool connect() ;
                    virtual unsigned char read();
                    virtual size_t read(unsigned char buffer[], size_t size);
                    virtual size_t write(unsigned char buffer[], size_t size);

                    const std::string& getHost() const {
                        return host;
                    }

                    void setHost(const std::string& host) {
                        this->host = host;
                    }

                    const int& getPort() const {
                        return port;
                    }

                    void setPort(const int& port) {
                        this->port = port;
                    }

                    arte::net::TCPSocket*& getSocket()  {
                        return socket;
                    }

                    void setSocket( arte::net::TCPSocket*& socket) {
                        this->socket = socket;
                    }
                    inline bool isConnected()const{
                        return socket->getSocket()>0;
                    }

                private:

                    arte::net::TCPSocket* socket;
                    std::string host;
                    int port;



        void
        initConnection(std::string host, int port, bool non_blocking);
      };

        }
    }
}
#endif /* NETWORKCONNECTION_H_ */

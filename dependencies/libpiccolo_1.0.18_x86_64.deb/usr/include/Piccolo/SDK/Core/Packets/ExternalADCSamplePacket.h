/*
 * ExternalADCSamplePacket.h
 *
 *  Created on: Jun 25, 2014
 *      Author: posilva
 */

#ifndef EXTERNALADCSAMPLEPACKET_H_
#define EXTERNALADCSAMPLEPACKET_H_
#include <stdint.h>
#include <Piccolo/SDK/SDK.h>
#include <Piccolo/SDK/Utils.h>
namespace Piccolo {
  namespace SDK {
    namespace Core {
      namespace Packets {

        class ExternalADCSamplePacket {
         private:
          uint16_t sourceId;
          float analog1;
          float analog2;
          float analog3;
          float analog4;
         public:
          ExternalADCSamplePacket();
          virtual ~ExternalADCSamplePacket();
          void load(BYTE_VECTOR* payload);

          uint16_t getSourceId() const {
            return sourceId;
          }

          void setSourceId(uint16_t sourceId) {
            this->sourceId = sourceId;
          }

          float getAnalog1() const {
            return analog1;
          }

          float getAnalog2() const {
            return analog2;
          }

          float getAnalog3() const {
            return analog3;
          }

          float getAnalog4() const {
            return analog4;
          }
        };

      } /* namespace Packets */
    } /* namespace Core */
  } /* namespace SDK */
} /* namespace Piccolo */

#endif /* EXTERNALADCSAMPLEPACKET_H_ */

/*
 * MissionLimitsPacket.h
 *
 *  Created on: Jun 25, 2014
 *      Author: posilva
 */

#ifndef MISSIONLIMITSPACKET_H_
#define MISSIONLIMITSPACKET_H_
#include <stdint.h>
#include <Piccolo/SDK/SDK.h>
#include <Piccolo/SDK/Utils.h>
namespace Piccolo {
  namespace SDK {
    namespace Core {
      namespace Packets {

        class MissionLimitsPacket {
         private:
          uint32_t commsTimeout;
          uint32_t pilotTimeout;
          uint32_t gpsTimeout;
          uint8_t lostCommWaypoint;
          uint8_t failure0;
          uint8_t failure1;
          uint8_t autolandWaypoint;
          int16_t altitudeMin;
          int16_t altitudeMax;
          uint32_t fligthTimeout;
          uint16_t sourceId;

         public:
          static const int MISSION_LIMITS_PACKET_SIZE = 24;
          MissionLimitsPacket();
          virtual ~MissionLimitsPacket();
          void load(BYTE_VECTOR* payload);

          //uint16_t toRaw(BYTE_VECTOR * payload);

          int16_t getAltitudeMax() const {
            return altitudeMax;
          }

          int16_t getAltitudeMin() const {
            return altitudeMin;
          }

          uint8_t getAutolandWaypoint() const {
            return autolandWaypoint;
          }

          uint32_t getCommsTimeout() const {
            return commsTimeout;
          }

          uint8_t getFailure0() const {
            return failure0;
          }

          uint8_t getFailure1() const {
            return failure1;
          }

          uint32_t getFligthTimeout() const {
            return fligthTimeout;
          }

          uint32_t getGpsTimeout() const {
            return gpsTimeout;
          }

          uint8_t getLostCommWaypoint() const {
            return lostCommWaypoint;
          }

          uint32_t getPilotTimeout() const {
            return pilotTimeout;
          }

          uint16_t getSourceId() const {
            return sourceId;
          }

          void setSourceId(uint16_t sourceId) {
            this->sourceId = sourceId;
          }
        };

      } /* namespace Packets */
    } /* namespace Core */
  } /* namespace SDK */
} /* namespace Piccolo */

#endif /* MISSIONLIMITSPACKET_H_ */

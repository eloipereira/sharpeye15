// ==========================================================================
// Copyright (C) 2013 Força Aérea Portuguesa - Academia                     =
// Centro de Investigação da Academiafa da Força Aérea                      =
// Granja do Marques, Academia, Pero-Pinheiro                               =
// ==========================================================================
// Project: PiccoloSDK-Debug@build
// Date:    Feb 20, 2013                                
// Author:  posilva                                
// -------------------------------------------------------------------------=
// Change Log:                                                         
// -------------------------------------------------------------------------=
// Date       / Author              /Description                          
// ==========================================================================
// Description: PayloadStream.h
// 
// ==========================================================================

#ifndef PAYLOADSTREAM_H_
#define PAYLOADSTREAM_H_

#include <Piccolo/SDK/SDK.h>

namespace Piccolo {
  namespace SDK {
    namespace Core {
      namespace Packets {

        class PayloadStream {
         public:
          PayloadStream();
          virtual
          ~PayloadStream();
          void load(BYTE_VECTOR *payload);
         protected:
          void parse(BYTE_VECTOR *payload);
          BYTE_VECTOR *payload;
        };

      } /* namespace Packets */
    } /* namespace Core */
  } /* namespace SDK */
} /* namespace Piccolo */
#endif /* PAYLOADSTREAM_H_ */

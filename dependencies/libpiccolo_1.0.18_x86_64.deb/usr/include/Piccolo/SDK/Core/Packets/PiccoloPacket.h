/*
 * PiccoloPacket.h
 *
 *  Created on: Jun 25, 2014
 *      Author: posilva
 */

#ifndef PICCOLOPACKET_H_
#define PICCOLOPACKET_H_
#include <Piccolo/SDK/SDK.h>

namespace Piccolo {
  namespace SDK {
    namespace Core {
      namespace Packets {

        class PiccoloPacket {
         public:
          PiccoloPacket();
          virtual ~PiccoloPacket();
          virtual void load(BYTE_VECTOR* payload)=0;
          virtual void load(BYTE_VECTOR*, size_t)=0;
          virtual BYTE_VECTOR* toRaw()=0;
          virtual uint16_t toRaw(BYTE_VECTOR * payload)=0;
        };

      } /* namespace Packets */
    } /* namespace Core */
  } /* namespace SDK */
} /* namespace Piccolo */

#endif /* PICCOLOPACKET_H_ */

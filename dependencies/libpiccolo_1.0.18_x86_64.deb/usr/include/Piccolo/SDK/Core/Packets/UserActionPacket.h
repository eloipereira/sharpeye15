/*
 * UserActionPacket.h
 *
 *  Created on: Jun 25, 2014
 *      Author: posilva
 */

#ifndef USERACTIONPACKET_H_
#define USERACTIONPACKET_H_
#include <stdint.h>
#include <Piccolo/SDK/SDK.h>
#include <Piccolo/SDK/Utils.h>
namespace Piccolo {
  namespace SDK {
    namespace Core {
      namespace Packets {

        class UserActionPacket {
         public:
          UserActionPacket();
          virtual ~UserActionPacket();
          void load(BYTE_VECTOR* payload);
          uint16_t
          toRaw(BYTE_VECTOR * payload);

          uint8_t getAction() const {
            return action;
          }

          void setAction(uint8_t action) {
            this->action = action;
          }

          bool isOn() const {
            return on;
          }

          void setOn(bool on) {
            this->on = on;
          }

          uint16_t getSourceId() const {
            return sourceId;
          }

          void setSourceId(uint16_t sourceId) {
            this->sourceId = sourceId;
          }

         private:
          uint16_t sourceId;
          uint8_t action;
          bool on;

        };

      } /* namespace Packets */
    } /* namespace Core */
  } /* namespace SDK */
} /* namespace Piccolo */

#endif /* USERACTIONPACKET_H_ */
